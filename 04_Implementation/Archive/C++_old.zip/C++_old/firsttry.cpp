
#include <fstream>
#include <iostream>
#include <string>
// #include <Windows.h>

#include "library/include/interaction_lib/InteractionLib.h"
#include "library/include/interaction_lib/misc/InteractionLibPtr.h"

// C3493a.cpp
int main()
{
    // create the interaction library
    IL::UniqueInteractionLibPtr intlib(IL::CreateInteractionLib(IL::FieldOfUse::Interactive));
    // assume single screen with size 2560x1440 and use full screen (not window local) coordinates
    constexpr float width = 2560.0f;
    constexpr float height = 1440.0f;
    constexpr float offset = 0.0f;
    intlib->CoordinateTransformAddOrUpdateDisplayArea(width, height);
    intlib->CoordinateTransformSetOriginOffset(offset, offset);
    // subscribe to gaze point data; print data to stdout when called
    intlib->SubscribeGazePointData([](IL::GazePointData evt, void *context)
                                   {
        std::ofstream outfile;
        outfile.open("csvdata.csv", std::ios_base::app);
        outfile << "x: " << evt.x
            << ", y: " << evt.y
            << ", validity: " << (evt.validity == IL::Validity::Valid ? "valid" : "invalid")
            << ", timestamp: " << evt.timestamp_us << " us"
            << "\n";
        outfile.close();

        std::cout
            << "x: " << evt.x
            << ", y: " << evt.y
            << ", validity: " << (evt.validity == IL::Validity::Valid ? "valid" : "invalid")
            << ", timestamp: " << evt.timestamp_us << " us"
            << "\n"; },
                                   nullptr);
    std::cout << "Starting interaction library update loop.\n";
    // setup and maintain device connection, wait for device data between events and
    // update interaction library to trigger all callbacks, stop after 100 cycles
    constexpr size_t max_cycles = 100;
    size_t cycle = 0;
    
    while (cycle++ < max_cycles)
    {
        intlib->WaitAndUpdate();
    }
   
    /* while (true)
    {
        if (GetKeyState('A') & 0x8000)
        {
            intlib->WaitAndUpdate();
        }
    } */
}