# C++ Implementation

## Requirements
### C++
C++ (cl.exe compiler) comes natively with VSCode when using the **x64 Native Tools Command Prompt for VS 2022**.

### Tobii Interaction Libraries and SDKs
Can be downloaded by using the guide, one folder level above.

## Usage
### Start
Navigate your terminal to this folder:
```
...\uas-ss-22-eye-tracking-video-meeting\04_Implementation\C++
```
and execute the command
```
cl.exe /EHsc /MD /I include <filename>.cpp /link /libpath:library\lib\x64 tobii_interaction_lib.lib tobii_stream_engine.lib
```
or 
```
cl.exe /EHsc /MD /I include <filename>.cpp /link  tobii_interaction_lib.lib tobii_stream_engine.lib  
```
to compile the application.
After that you can simply execute the new .exe file.